function getBotResponse(input) {
  const responses = {
    'hello': 'Hello there!',
    'goodbye': 'Talk to you later!',
    'thank you': 'welcome!',
    'hi there': 'hi users',
    'address': 'No 10 C, 10c1, 10c2, OmSakthinagar, Chinnavedampatti Road-Ganapathy, Coimbatore - 641006, Near Chinnavedampatti Lake.',
    'product': 'v4 18 slot ,v4 24 slot ,al3 slot,v7,1080 mono block , 1080 open well, ga 80, 1100',
    'products': 'v4 18 slot ,v4 24 slot ,al3 slot,v7,1080 mono block , 1080 open well, ga 80, 1100',
    'phone no': '+91 94738263782 +91 2838929827',
    'phone': '+91 94738263782 +91 2838929827',
    'ph no': '+91 94738263782 +91 2838929827',
    'personal number': '+91 94738263782 +91 2838929827',
    'location': 'https://goo.gl/maps/F1KCf7hrRkpVH29Z9',
    'phone number': '+91 94738263782 +91 2838929827',
    'time': '9.30am - 6.00pm sunday closed',
    'timing': '9.30am - 6.00pm',
    'available timing': '9.30am - 6.00pm',
    'available time': '9.30am - 6.00pm sunday closed',
    'hi': 'Hi there',
  };
  
  const inputKeywords = input.toLowerCase().split(' ');
  for (let i = 0; i < inputKeywords.length; i++) {
    if (inputKeywords[i] in responses) {
      return responses[inputKeywords[i]];
    }
  }
  
  return 'Try asking something else!';
}
